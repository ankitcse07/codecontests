using namespace std;
#include <iostream>
#include <set>
#include <unistd.h>
#include <iostream>
#include <fstream>


int main(int argc,const char* argv[]) {
    if(argc != 4 ) {
        cout << " bad comand:\n  ./app <TOTAL_NODES> <SOURCE_NODES> <SINK_NODES>\n";
        return 1; 
    }

    int TOTAL_NODES  = atoi(argv[1]);
    int SOURCE_NODES = atoi(argv[2]);
    int SINK_NODES   = atoi(argv[3]);

    if((TOTAL_NODES < 1) || (SOURCE_NODES < 1) || (SINK_NODES < 1))
        return 1;

    if((SOURCE_NODES > TOTAL_NODES) || (SINK_NODES > TOTAL_NODES))
        return 1;

    system("rm -rf CodeContest2014");
    system("mkdir CodeContest2014");

    ofstream write1 ("CodeContest2014/input_graph");

    srand(time(NULL));
    write1<< "graph testinput {\n";
    set <int> totalSet;
    for (int i = 0; i < TOTAL_NODES; i++) {
         int gen1 = 1+ (random() % TOTAL_NODES);
         int gen2 = 1+ (random() % TOTAL_NODES);
         write1 <<gen1<<"--"<<gen2 <<"\n";
         totalSet.insert(gen1);
         totalSet.insert(gen2);

    } 
    write1 << "}\n";
    write1.close();

    
    ofstream write2 ("CodeContest2014/new_employee_list");
    int sourceCount = 0;
    int sinkCount = 0;
    set <int> sourceSet;
    set<int>::iterator ret;
    set <int> sinkSet;
    set<int>::iterator ret2;
    set<int>::iterator ret3;
    do {
        int gen = 1 + (random() % TOTAL_NODES);

        ret3 = totalSet.find(gen);
        if(ret3 == totalSet.end()) {
            continue;
        }


        ret =  sourceSet.find(gen);
        if(ret == sourceSet.end()) {
            sourceCount++;
            sourceSet.insert(gen);
            write2 << gen << "\n";
        }
    } while(sourceCount!= SOURCE_NODES);

    write2.close();


    ofstream write3 ("CodeContest2014/sme_list");
    do {
        int gen = 1 + (random() % TOTAL_NODES);

        ret3 = totalSet.find(gen);
        if(ret3 == totalSet.end()) {
            continue;
        }

        ret =  sourceSet.find(gen);
        if(ret != sourceSet.end()) {
            continue;
        }
        ret2 =  sinkSet.find(gen);
        if(ret2 == sinkSet.end()) {
            sinkCount++;
            sinkSet.insert(gen);
            write3 << gen << "\n";
        }
    }while(sinkCount!= SINK_NODES);

    write3.close();
    return 0;
}



